package lesson12;

public class DemoAbstract {

    public static void main(String[] args) {
        Car car = new Car();
        car.accelerate();

        car.setName("asd");
        System.out.println(car.getName());

        
    }
}
