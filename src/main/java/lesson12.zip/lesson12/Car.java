package lesson12;

public class Car extends Vehicle {
    public void accelerate() {
        System.out.println("Car accelerating");
    }

    public void slowDown() {
        System.out.println("Car slowing down");
    }

}
