package lesson12;

public class IphoneX implements MobilePhone {

    public void makeASound() {
        System.out.println("Make an expensive Iphone sound");
    }

    @Override
    public void checkSignal() {

    }

//    public void call(){
//        System.out.println("Call method overridden");
//    }


}
