package lesson12.books;

public interface GenericBook {
}
