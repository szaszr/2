package lesson12.books;

public class MainBookClass {

    public static void main(String[] args) {
        BookLibrary bookLibrary = new BookLibrary();
        bookLibrary.addBook("123");

        // list all books
        for (Book allAvailableBook : bookLibrary.getAllAvailableBooks()) {
            System.out.println(allAvailableBook.getIsbn());
        }
    }
}
