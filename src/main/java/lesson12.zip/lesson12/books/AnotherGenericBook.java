package lesson12.books;

public interface AnotherGenericBook {
}
