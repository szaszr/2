package lesson12;

public class Bycicle extends Vehicle {
    public void accelerate() {
        System.out.println("accelerating the bycicle");
    }

    public void slowDown() {
        System.out.println("slow down the bycicle");
    }
}
