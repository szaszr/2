package lesson12;

public class SUV extends Car {

    public void accelerate(){
        System.out.println("Accelerate the SUV");
    }
}
